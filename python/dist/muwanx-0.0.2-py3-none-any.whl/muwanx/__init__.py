"""Muwanx - Browser-based MuJoCo simulation with real-time policy control."""

__version__ = "0.0.2"
